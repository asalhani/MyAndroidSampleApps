package com.jwhh.jim.firstapp;

/**
 * Created by Jim.
 */

public class MyWorker {
    public static int doubleTheValue(int value) {
        return value * 2;
    }
}
